# Yêu cầu sửa V7

[Theo nguồn] = Fact/Conflict có căn cứ cần sửa; [Cần duyệt] = Proposal chưa được duyệt. Không tự biến đề xuất thành quy tắc nghiệp vụ. Các dòng [Đã sửa] mô tả sản phẩm có trong gói sơ bộ.

| Chỗ cần sửa | Cách sửa cụ thể | Nguồn đối chiếu | Tiêu chí chấm đạt |
|---|---|---|---|
| 06.2 — phân nhánh làm mịn/san bằng/bế tắc | [Theo nguồn] Tách thành các hướng có guard, nối mỗi hướng tới action đúng nghĩa rồi hội tụ; không thực hiện làm mịn rồi luôn san bằng tuần tự. | CN-78–82,86; AD gốc V7 | Walkthrough từng nhánh không đi nhầm action; làm mịn không tự đổi baseline. |
| 06.1/06.2/06.3 — ranh giới, actor | [Theo nguồn] Phân tích ngưỡng thuộc 06.1; phân xử thuộc 06.3. Trong 06.2 PM đàm phán, RM điều phối/ghi nhận. Sửa cột RM đang gán cho câu PM đàm phán, không dời toàn bộ action sang RM. | CN-74–85; HD-PCCN §3 | D/AD cùng phân vai; UCD không include chỉ để chỉ thứ tự. |
| A3/A4, E1 và các chi tiết kỹ thuật | [Theo nguồn] Bỏ tỷ lệ 50/50 bắt buộc, chức năng thuê ngoài khẩn chưa có căn cứ và cách gọi dưới ngưỡng bằng <20%. Giữ tham chiếu overtime khẩn theo Mức 5/DoA tại đúng UC. Không tự thêm dịch vụ tính CPM/mô phỏng. | I.1.3.7; QT-33–38; RB-59 | Không xóa nghiệp vụ overtime có nguồn; không có ngưỡng/tỷ lệ hay thuật toán tự đặt. |
| Lớp và II.4 nháp | [Theo nguồn] Dùng lớp chung và nhật ký nghiệp vụ; bỏ hash/lưu vĩnh viễn nếu không có nguồn. Sequence phải có người PMO/CEO quyết định, hồ sơ chỉ ghi nhận. | CN-83–88; II.3; Outline II.4 | Không thông điệp nào khiến hồ sơ tự sinh phán quyết; trạng thái không chỉ là tên thao tác. |
| Khoảng hở thang tải | [Cần duyệt Q-06] Không tự gán khoảng 100–120% vào một mức mới; giữ điều kiện riêng có nguồn, trình trưởng nhóm chốt thang. | I.1.3.7; RB-59; CN-50,70 | Không có quy tắc phân loại mới được viết như đã duyệt. |
