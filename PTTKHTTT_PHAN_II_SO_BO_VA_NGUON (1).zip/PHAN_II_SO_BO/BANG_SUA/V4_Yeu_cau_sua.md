# Yêu cầu sửa V4

[Theo nguồn] = Fact/Conflict có căn cứ cần sửa; [Cần duyệt] = Proposal chưa được duyệt. Không tự biến đề xuất thành quy tắc nghiệp vụ. Các dòng [Đã sửa] mô tả sản phẩm có trong gói sơ bộ.

| Chỗ cần sửa | Cách sửa cụ thể | Nguồn đối chiếu | Tiêu chí chấm đạt |
|---|---|---|---|
| UCD cấp vùng | [Theo nguồn] Dùng hình chung đủ 03.1–03.4. Giữ PMO ở 03.3/03.4 theo CN-37/43; không yêu cầu thêm lại PMO vào hình 03.3 gốc vì đã có. | CN-31–46; UCD gốc V4 | Đủ bốn UC, PMO nối đúng hai UC; không đổi ID. |
| 03.3 — cạn ứng viên và phản hồi V2 | [Theo nguồn] Nhánh không có ứng viên đạt quay 03.2 thử nguồn kế tiếp; khi đã thử các cách vẫn không đáp ứng, RM gửi phản hồi CN-46 cho V2/01.3. | CN-33,46; CN-17; HD-PCCN §3 | Không phản hồi thất bại trước khi xét quy tắc nguồn; V2 nhận được lý do. |
| Lớp V4 và dữ liệu V3/V5 | [Theo nguồn] Dùng BoTieuChiPhuHop, TieuChiPhuHop, KetQuaDanhGiaPhuHop; kỹ năng cá nhân tham chiếu NangLucKyNang. Giữ lý do loại, căn cứ tin cậy, phiên tiêu chí và nội dung miễn trừ. | CN-32,36–44; II.3 | Không trùng bộ tiêu chí năng lực V3; miễn trừ biết điều kiện và người duyệt. |
| PMO–V4 trong bảng vai trò Phần I | [Cần duyệt Q-01] Đề nghị trưởng nhóm bổ sung V4 vào I.1.2 để khớp CN-37/43. Không tự sửa I FINAL. | I.1.2 so với CN-37/43 | Quyết định được ghi nhận; sơ đồ không bị sửa mất hành vi phê duyệt có nguồn. |
