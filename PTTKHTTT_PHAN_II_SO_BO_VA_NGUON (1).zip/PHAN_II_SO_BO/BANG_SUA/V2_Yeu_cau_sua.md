# Yêu cầu sửa V2

[Theo nguồn] = Fact/Conflict có căn cứ cần sửa; [Cần duyệt] = Proposal chưa được duyệt. Không tự biến đề xuất thành quy tắc nghiệp vụ. Các dòng [Đã sửa] mô tả sản phẩm có trong gói sơ bộ.

| Chỗ cần sửa | Cách sửa cụ thể | Nguồn đối chiếu | Tiêu chí chấm đạt |
|---|---|---|---|
| 01.1 — actor ở §2.1/§3.1 và UCD | [Theo nguồn] PM lập nhu cầu; RM xác nhận ở 01.2. Bỏ System khỏi danh sách actor. | I FINAL I.1.2, CN-01–17 | UCD vùng có PM–01.1, RM–01.2; Description không gọi System là actor. |
| 01.1 — A2, quy mô FTE và các nhánh sửa của AD | [Theo nguồn] Bỏ giới hạn tổng nhu cầu ≤1 FTE; phân biệt quy mô theo loại/giai đoạn với %FTE của dòng tham gia. Nối action sửa mốc/FTE quay lại kiểm tra. Giữ A1 đã có, chỉnh rõ bổ sung thông tin dự án CN-03. | CN-03, 06–08; PCN-09; AD gốc V2a | Nhu cầu 2 người toàn thời gian không bị chặn vì tổng >1; nhánh lỗi không dừng ở action treo; không tạo A1 trùng. |
| 01.1 — cuối D/AD và hậu điều kiện | [Theo nguồn] Thêm PM chuyển nhu cầu hoàn thiện cho RM; hệ thống ghi nhận việc chuyển. Lưu nháp và gửi là hai kết quả phân biệt. | CN-11–12 | Có bước gửi RM ở cả D/AD; chưa xác nhận không bàn giao V3/V4. |
| 01.2/01.3 — bảng quan hệ và phần sửa nhu cầu | [Theo nguồn] Sửa ô tự-extend 01.3→01.3 thành 01.3→01.2. Đặt hành vi PM sửa tại 01.3; 01.2 trả lại rồi RM xem xét lại khi gửi lại. Giữ cách khởi tạo 01.3 từ V4/V10. | CN-10, 14–17; UCD V2b | Không cập nhật Đã xác nhận ngay sau PM sửa; phản hồi V4/V10 không bị bỏ. |
| 01.2 — mô tả merge và bàn giao | [Theo nguồn] Sửa lời §4.1 theo hình quay về trước RM xem xét; thể hiện RM yêu cầu bàn giao và hệ thống chuyển, không dời toàn bộ truyền dữ liệu sang RM. | CN-13,16; AD V2b | Hình/văn bản cùng điểm quay lại; có người yêu cầu và hành vi hỗ trợ rõ. |
| V2b — §7–12 và lớp dùng chung | [Theo nguồn] Cung cấp bản V2b cập nhật để thay các bảng mẫu; dùng NhuCauNguonLuc, ViTriCanBoTri, YeuCauKyNang, PhanHoiNhuCau trong mô hình chung; giữ dữ liệu phạm vi công việc. | DOCX V2b trong main; II.3 bản sơ bộ | Không còn dấu … ở sản phẩm giao; mỗi thuộc tính được gắn đúng nhu cầu hoặc vị trí. |
| V2 — tên trạng thái, lớp CongViec | [Cần duyệt Q-02] Chuẩn hóa tên trạng thái giữa hai người. Chưa tự bổ sung vòng đời công việc riêng; giữ phạm vi công việc như dữ liệu của nhu cầu trong bản sơ bộ. | CN-10–17; QT-01–05 | Một bộ tên trạng thái duy nhất sau duyệt; không đổi nghĩa đã xác nhận. |
