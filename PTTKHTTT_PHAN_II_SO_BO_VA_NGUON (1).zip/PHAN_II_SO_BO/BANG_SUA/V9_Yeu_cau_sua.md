# Yêu cầu sửa V9

[Theo nguồn] = Fact/Conflict có căn cứ cần sửa; [Cần duyệt] = Proposal chưa được duyệt. Không tự biến đề xuất thành quy tắc nghiệp vụ. Các dòng [Đã sửa] mô tả sản phẩm có trong gói sơ bộ.

| Chỗ cần sửa | Cách sửa cụ thể | Nguồn đối chiếu | Tiêu chí chấm đạt |
|---|---|---|---|
| UC-08.1 trong D/AD đang mang phạm vi cả vùng | [Theo nguồn] Giữ bốn mã 08.1–08.4; chuyển nội dung tính, đối chiếu, so sánh, hướng xử lý về đúng mục. Tái dùng lớp và dữ liệu chung, không viết lại toàn bài. | HD-PCCN §1,3; CN-103–112,128–129 | Tên 08.1 là Tính và cập nhật chi phí phương án; đủ bốn FDS và không trùng hành vi sở hữu. |
| 08.2/08.3 — action System trong AD | [Theo nguồn] PM/Tài chính đối chiếu theo CN-108/109, PM so sánh theo CN-110; System tính/hiển thị hỗ trợ. Không tự chọn thay PM. | CN-108–110; AD 4. Activity Diagram.drawio | D/AD nêu người quyết định/đối chiếu; dữ liệu hỗ trợ đúng bước. |
| 08.4 — Gắn cấp thay cho quyết định ngân sách | [Theo nguồn] ≤10% có PM tự điều chỉnh hoặc xin PMO; >10% chuyển CEO. Thêm người có thẩm quyền ra và ghi quyết định, hoặc dừng rõ ở chuyển 08.4. | QT-51; CN-111,128–129 | Gắn cấp không được coi là đã phê duyệt; ngân sách khác quyết định phương án ở V8. |
| E1 dữ liệu thiếu | [Theo nguồn] AD phải thể hiện yêu cầu Tài chính bổ sung như D, không chỉ đánh dấu rồi kết thúc; chưa đủ dữ liệu không kết luận chính thức. | D V9 §3.3 E1; CN-103–109 | D/AD cùng kết quả thiếu dữ liệu và người cần bổ sung. |
| Lớp V9, hình UCD và nguồn | [Theo nguồn] Dùng ChiTietBoTri cho dòng phương án; giữ căn cứ dự toán/dự báo của lần đánh giá; bổ sung UCD nguồn hoặc xuất có mxfile nhúng để thay link Drive. | II.3; class V9; HD-MAU §2.3 | Từ đánh giá truy được số liệu tại thời điểm đánh giá; báo cáo có hình, không chỉ link. |
| Công thức tỷ lệ vượt/đơn vị/0 hoặc âm | [Cần duyệt Q-07] Ghi công thức hiện có là giả định; chưa tự chia khi ngân sách còn lại ≤0 hoặc tự chọn cấp duyệt từ kết quả không xác định. | QT-51; D V9 A2 | Có công thức, đơn vị, cách xử lý trường hợp biên được duyệt trước khi tính minh họa. |
