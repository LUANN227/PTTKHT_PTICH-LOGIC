# Yêu cầu sửa V6

[Theo nguồn] = Fact/Conflict có căn cứ cần sửa; [Cần duyệt] = Proposal chưa được duyệt. Không tự biến đề xuất thành quy tắc nghiệp vụ. Các dòng [Đã sửa] mô tả sản phẩm có trong gói sơ bộ.

| Chỗ cần sửa | Cách sửa cụ thể | Nguồn đối chiếu | Tiêu chí chấm đạt |
|---|---|---|---|
| 05.1 — cuối AD | [Theo nguồn] Kết thúc ở gửi và ghi nhận gửi PM. Bỏ quyết định PM phê duyệt khỏi 05.1; PM rà soát thuộc 05.2, phê duyệt tổng thể thuộc V8. | CN-68–69; HD-PCCN §3 | 05.1 không tạo Locked Baseline; D/AD cùng điểm kết thúc. |
| 05.2 — đặc tả điểm bàn giao | [Theo nguồn] Bổ sung FDS rõ PM rà soát/xác nhận hoặc yêu cầu sửa; RM đối chiếu tải/lịch và chuyển V7 hoặc V8/V9. Không gọi 05.2 là nơi tạo phương án. | CN-69–72 | Có đủ hướng sửa, nghi ngờ xung đột và không nghi ngờ; actor PM/RM đúng bước. |
| 05.1 — quay lại sửa và hạn 3 ngày | [Theo nguồn] Nhánh nhận phản hồi phải quay về sửa phương án thay vì kết thúc. Mô tả CN-73 là theo dõi trạng thái đang xây dựng; có cách báo cáo PMO khi quá hạn. | CN-62,69,73; QT-31 | Không kết thúc ở Nhận phản hồi; hạn 3 ngày được theo dõi, không chèn kiểm tra lặp ở mọi action. |
| Dữ liệu liên vùng V5/V10 và lớp | [Theo nguồn] Dùng PhanBoNguonLuc cho lịch, KetLuanKhaNangThamGia cho kết quả V5. ChiTietBoTri gắn người, vị trí, giai đoạn, tỷ lệ/thời gian. | CN-61–62; QT-29; II.3 | Cùng vị trí có thể bố trí khác tỷ lệ theo giai đoạn; không tạo lịch nguồn lực thứ hai ở V6. |
| Lần trình/phiên bản phương án | [Cần duyệt Q-05] Xác nhận với V8 cách phân biệt sửa hồ sơ và trình lại; chưa cố định 1:1 hồ sơ–phương án. | CN-96,101–102 | V6/V8 dùng cùng định danh phiên bản và lần trình sau duyệt. |
