# Yêu cầu sửa V3

[Theo nguồn] = Fact/Conflict có căn cứ cần sửa; [Cần duyệt] = Proposal chưa được duyệt. Không tự biến đề xuất thành quy tắc nghiệp vụ. Các dòng [Đã sửa] mô tả sản phẩm có trong gói sơ bộ.

| Chỗ cần sửa | Cách sửa cụ thể | Nguồn đối chiếu | Tiêu chí chấm đạt |
|---|---|---|---|
| 02.1 — thiếu tiêu chí tạm trong D/AD/UCD | [Theo nguồn] Thêm RM đề xuất tiêu chí tạm, PMO duyệt/từ chối; chờ duyệt không được sử dụng. Thêm actor/làn PMO tại đúng nhánh. | CN-18–19 | Có nhánh CN-19 ở D và AD, có PMO trên UCD; tiêu chí chưa duyệt không thành sẵn sàng. |
| 02.1 — BR và thang năng lực | [Theo nguồn] Điền BR còn mẫu; thay mã QT-01..04 đang thuộc V2 bằng CN-18/19 và QT-06..11 thực sự liên quan; ghi thang 5 mức. | I FINAL I.1.4, CN-18; HD-MAU §3.4 | Không còn số mức Chưa xác định; từng mã dẫn hỗ trợ đúng nội dung. |
| 02.2/02.3 — FDS tóm tắt và dữ liệu đầu ra | [Theo nguồn] Bổ sung tóm tắt đúng 02.2 đánh giá và 02.3 xác nhận/cập nhật; mô tả tự khai báo, cần kiểm chứng, đã xác nhận; chứng chỉ hết hiệu lực và tranh chấp. Không gọi 02.2 là duyệt hồ sơ. | CN-20–30; FDS Summary chung | V4/V5/V10 truy được hồ sơ năng lực tập trung; không có trạng thái Hiệu lực tự thêm. |
| Lớp năng lực — danh mục và năng lực của người | [Theo nguồn] Phân biệt KyNang, NangLucKyNang, HoSoNangLuc và TieuChiNangLuc. Không dựng lớp RM chỉ để chứa thao tác gửi yêu cầu. | QT-06–11; CN-23–30; II.3 | Kỹ năng của hai người có thể có mức/trạng thái khác nhau, vẫn dùng chung danh mục. |
| UC cá nhân 02.1 hay 02.2 | [Cần duyệt Q-03] Giữ 02.1 trong bản sơ bộ; đề xuất 02.2 nếu cần đổi UC cá nhân có chiều sâu hơn. Không tự đổi phân công. | HD-PCCN §5; Outline yêu cầu UC cá nhân | UC cá nhân được xác nhận bằng mã/tên; nội dung 02.1 đã làm không bị bỏ. |
