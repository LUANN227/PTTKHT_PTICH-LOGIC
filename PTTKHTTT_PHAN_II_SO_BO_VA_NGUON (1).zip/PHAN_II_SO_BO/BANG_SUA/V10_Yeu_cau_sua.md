# Yêu cầu sửa V10

[Theo nguồn] = Fact/Conflict có căn cứ cần sửa; [Cần duyệt] = Proposal chưa được duyệt. Không tự biến đề xuất thành quy tắc nghiệp vụ. Các dòng [Đã sửa] mô tả sản phẩm có trong gói sơ bộ.

| Chỗ cần sửa | Cách sửa cụ thể | Nguồn đối chiếu | Tiêu chí chấm đạt |
|---|---|---|---|
| 09.1/09.2 — D và AD mới | [Đã sửa trong bản sơ bộ] Rút gọn action; giữ fork cung/cầu, sàng lọc nhu cầu, phân tích bốn chiều, quyết định chuyển do RM và đúng nơi nhận. | CN-113–126; I.1.3.10; I.3.9 | Đối chiếu bộ kịch bản V10 trong tài liệu; quyết định chuyển thuộc RM; dẫn đúng I.3.9 bước 7 và điểm Q-09. |
| 09.1 E1 thiếu nguồn cung | [Đã sửa theo nguồn] Ghi thiếu và yêu cầu bổ sung; khi chưa đủ cơ sở thì kết thúc lần chạy bằng kết quả tạm, chưa phát dự báo chính thức. Không ngầm chạy tiếp như bản cũ. | CN-113; I.1.3.10 bước 1; QT-55 | Nhánh E1 không đi tới dự báo chính thức; dữ liệu thiếu vẫn được thể hiện. |
| Nhu cầu đã xác nhận/dự kiến/chưa đủ cơ sở | [Đã sửa theo nguồn] Tách trạng thái nhu cầu với mức chắc chắn; chỉ nhu cầu đủ trạng thái, mức chắc chắn, thời gian, phạm vi được đưa vào dự báo. | CN-114,116–117; QT-55 | Dự kiến không tự biến thành đã xác nhận; chưa đủ cơ sở không được đưa vào. |
| Mô hình dự báo một phần và nhu cầu rỗng | [Cần duyệt Q-08] Nếu muốn dự báo phần đủ dữ liệu khi cung thiếu, chốt phạm vi và nhãn kết quả trước. Bản sơ bộ không coi dữ liệu rỗng là cầu bằng 0; trả RM xác nhận cơ sở. | I.1.3.10; QT-55; CN-116–119 | Không suy diễn thừa nguồn từ danh sách thiếu/rỗng; phương án dự báo một phần chỉ áp dụng sau duyệt. |
| Dữ liệu liên vùng và nguồn chỉnh sửa | [Đã đồng bộ] V3 hồ sơ, V5 lịch/phân bổ, V8 cam kết, V7 xử lý xung đột; V9 chỉ căn cứ tổng hợp. Giữ file drawio từng phần tử và PNG đi kèm. | PCN-02–03; CN-94,100,112,124; QT-57 | Không dùng lịch sử/cơ hội/chi phí để dự báo; không tạo lịch/hồ sơ gốc thứ hai tại V10. |
| 09.1 — Điều kiện chuyển kết quả | [Conflict / Cần duyệt Q-09] Không gọi điều kiện khác kỳ trước là tự đặt: I.3.9 bước 7 có câu này. Giữ quyết định RM theo I.1.3.10/CN-121; chốt điều kiện bắt buộc chuyển hay căn cứ cân nhắc. | I FINAL I.1.3.10 bước 6–7; I.3.9 bước 7; CN-121 | Có quyết định của RM; nhóm xác nhận cách đọc hai đoạn nguồn trước khi tự động hóa. |
