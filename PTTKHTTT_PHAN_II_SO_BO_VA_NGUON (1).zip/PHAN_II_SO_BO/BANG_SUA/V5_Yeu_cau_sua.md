# Yêu cầu sửa V5

[Theo nguồn] = Fact/Conflict có căn cứ cần sửa; [Cần duyệt] = Proposal chưa được duyệt. Không tự biến đề xuất thành quy tắc nghiệp vụ. Các dòng [Đã sửa] mô tả sản phẩm có trong gói sơ bộ.

| Chỗ cần sửa | Cách sửa cụ thể | Nguồn đối chiếu | Tiêu chí chấm đạt |
|---|---|---|---|
| 04.1 — kết luận và các điểm bàn giao trên AD | [Theo nguồn] Mỗi ứng viên có trạng thái/căn cứ trước bàn giao. Dữ liệu thiếu giữ kết quả tạm/chờ xác nhận; không ép nhánh này thành đánh giá hoàn tất. Nhánh một phần chuyển 04.2, ngoại lệ chuyển 04.3. | CN-47–59 | D/AD có cùng bốn trạng thái; không nhánh nào được bàn giao như kết luận đủ căn cứ khi dữ liệu thiếu. |
| 04.1 — A2 và cờ quá tải | [Theo nguồn] Thể hiện chờ xác nhận 2 ngày; nếu không chờ thì coi chưa có dữ liệu và yêu cầu xác nhận ngay. Ghi rõ >90% kéo dài >2 tuần; cờ Mức 2 không tự kích hoạt V7. | CN-50,52; QT-24–26 | Có cả nhánh chờ/không chờ; tình huống Mức 2 không tự chạy xử lý xung đột. |
| D/AD — từng ứng viên và trách nhiệm RM/System | [Theo nguồn] Dùng một vòng hoặc ghi rõ xử lý trên từng ứng viên. Đặt RM đánh giá/ghi nhận kết luận, hệ thống tính/tra cứu hỗ trợ; nối nhánh kết thúc hợp lệ. | CN-48–51; HD-MAU §4 | Shortlist nhiều người cho kết quả riêng; không action treo hoặc kết thúc bằng hộp chữ. |
| Class V5 — xác nhận một phần, hạn xác nhận và bội số | [Theo nguồn] Sửa ghiNhanXacNhanPMO thành PM theo CN-54. Giữ lý do/ngày yêu cầu/hạn xác nhận dù gộp lớp YeuCauXacNhan. Kết quả bình thường không bắt buộc có hồ sơ ngoại lệ. | CN-52,54,57; hình và bảng lớp V5; II.3 | Phương thức đúng PM; theo dõi được 2 ngày; bảng/hình không mâu thuẫn 1..* và 0..*. |
| A6 — ngưỡng khẩn cấp 24–48 giờ | [Cần duyệt Q-04] Giữ đánh giá nhanh theo phân bổ cứng, chưa chuyển 24–48 thành một ngưỡng số duy nhất. | CN-58; I.1.3.5 | Không tự chốt 24 hay 48; có chỗ ghi quyết định để cập nhật guard. |
