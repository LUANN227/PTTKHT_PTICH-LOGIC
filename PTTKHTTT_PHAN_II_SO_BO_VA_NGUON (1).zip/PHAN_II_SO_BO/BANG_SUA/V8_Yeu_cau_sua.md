# Yêu cầu sửa V8

[Theo nguồn] = Fact/Conflict có căn cứ cần sửa; [Cần duyệt] = Proposal chưa được duyệt. Không tự biến đề xuất thành quy tắc nghiệp vụ. Các dòng [Đã sửa] mô tả sản phẩm có trong gói sơ bộ.

| Chỗ cần sửa | Cách sửa cụ thể | Nguồn đối chiếu | Tiêu chí chấm đạt |
|---|---|---|---|
| UCD vùng từ PNG có mxfile nhúng | [Theo nguồn] Giữ nguồn nhúng; dùng đủ 07.1–07.4. Bỏ include toàn vùng V9/V10 và cạnh 07.3 include 07.1 dùng để kể trình tự; giữ 07.2 extend 07.1 có điều kiện. | CN-89–102; RB-61; UCD gốc V8 | Đủ bốn mã; thông tin V9/V10 là tham chiếu dữ liệu, không gọi lại cả vùng. |
| 07.1 — tự đối chiếu DoA và Ra quyết định trước đủ cơ sở | [Theo nguồn] PMO đối chiếu DoA có hệ thống hỗ trợ; sửa Cho phép PMO tự phê duyệt/Ra quyết định thành rà soát và kết luận đủ cơ sở. Quyết định chính thức đặt tại 07.3/07.4. | CN-90–98; AD V8 | Không có phê duyệt trong 07.1; không ra quyết định trước khi kết luận hồ sơ đủ cơ sở. |
| 07.2 — quay lại sau giải trình | [Theo nguồn] Hồ sơ bổ sung quay về rà soát lại; thay đổi phân bổ hoặc xung đột thì trả V6/V7. Không quay thẳng decision chọn người ra quyết định. | CN-95–96,101 | Có cả hai hướng sau giải trình; phiên bản cập nhật được rà soát lại. |
| 07.3/07.4 — phần chưa đặc tả | [Theo nguồn] Viết tóm tắt đủ quyết định, lý do/điều kiện, người/thời điểm và Locked Baseline; ngoại lệ có điều kiện hoàn trả/rà soát lại theo nguồn. | CN-97–102; I.1.3.8 | Không mất 07.4; V10 chỉ nhận cam kết đã được duyệt. |
| Class V8 — bội số và dữ liệu V9/V10 | [Theo nguồn] Đồng bộ bảng/hình YeuCauGiaiTrinh 0..1 với nhiều đợt trong D; thống nhất số kết quả dự báo tham chiếu. Dùng DanhGiaChiPhi/KetQuaDuBao thay bản sao không rõ sở hữu. | DOCX V8 §11; class PNG nhúng; CN-93–96; II.3 | Một cách biểu diễn được dùng cả D/hình; nguồn dữ liệu vẫn thuộc V9/V10. |
| HoSoTrinhDuyet–PhuongAnBoTri | [Cần duyệt Q-05] Chốt lần trình, phiên bản và bội số với V6; bản chung không ép 1:1 khi nguồn chưa quy định. | CN-101–102 | Có quy ước dùng chung trước khi triển khai Sequence/State. |
