# Nội dung dùng chung và điểm chờ quyết định

## Đã chuẩn hóa theo nguồn trong bản sơ bộ

- Giữ 9 vùng và 28 ID/tên UC theo HD-PCCN §1; không thêm, xóa hoặc gộp UC.
- FDS Summary đầy đủ 28 UC; phân bổ CN theo nội dung I FINAL, không theo dải số sai trong Summary cũ.
- RM/PM ở V10; PMO ở V4 theo hành vi CN-37/43; bàn giao liên vùng không dùng include để thay luồng dữ liệu.
- UC trọng tâm giữ lựa chọn đang dùng: 01.1, 01.2, 01.3, 02.1, 03.3, 04.1, 05.1, 06.2, 07.1, 08.1, 09.1, 09.2. 08.1 chỉ giữ đúng phạm vi mã, không gọi là UC gộp cả V9.
- II.3 giữ các lớp có căn cứ; bỏ lớp đề xuất YeuCauNguonLuc khi chưa có vòng đời được chốt; CN-127 được biểu diễn là hành vi gửi nhu cầu/khung thời gian. Nếu duyệt lớp riêng, phải thêm quan hệ và cập nhật đồng bộ.
- II.3 tách dòng phương án, phân bổ lịch, hồ sơ trình và kết quả phê duyệt; giữ dữ liệu xác nhận có hạn; nhu cầu dự kiến V10 có dự án, trạng thái và phạm vi. Các bội số chưa đủ nguồn không gán số.
- V10 E1 không còn tự tiếp tục dự báo chính thức; RM quyết định chuyển thông tin, điều kiện thiếu/dư hoặc khác kỳ trước có ở I.3.9 bước 7; quan hệ với quyền quyết định RM cần chốt Q-09.
- Báo cáo chính không đưa bảng ứng viên lớp, audit hoặc đề xuất kỹ thuật; những nội dung chờ duyệt nằm ở file này.
- II.4 giữ đủ II.4.1 trạng thái, II.4.2 giao tiếp, II.4.3 tuần tự theo Outline; chỉ có vị trí chờ, không dựng mô hình giả định.

## Phạm vi đặc tả của bản sơ bộ

Theo yêu cầu lượt này, UC trọng tâm có vị trí Description và AD; UC còn lại có FDS tóm tắt riêng theo mã. Outline dùng cụm mô tả cho từng ca sử dụng: bảng tóm tắt bảo toàn đủ mục tiêu, actor, đầu vào, phạm vi, kết quả và nguồn; mức chi tiết/AD bổ sung của UC phụ cần đối chiếu yêu cầu giảng viên trước bản nộp cuối. Không tự cắt yêu cầu II.4.

## Các điểm còn cần quyết định

| Mã | Nội dung | Phương án đề xuất | Trạng thái |
|---|---|---|---|
| Q-01 | PMO–V4 trong I.1.2 | Giữ PMO ở II.1/03.3/03.4 theo CN-37/43; đề nghị bổ sung V4 vào bảng I.1.2. | Chờ duyệt thay đổi baseline; không sửa I FINAL. |
| Q-02 | Tên trạng thái và cấu trúc nhu cầu | Một bộ tên cho V2; giữ phạm vi công việc, vị trí, giai đoạn; không thêm module công việc. | Chờ V2/trưởng nhóm xác nhận tên dùng chung. |
| Q-03 | UC cá nhân V3/V8 | Giữ 02.1 và 07.1 đang làm; đề xuất 02.2 hoặc 07.3 chỉ nếu nhóm quyết định đổi bài. | Chưa đổi phân công. |
| Q-04 | Yêu cầu khẩn dưới 24–48 giờ | Giữ nhánh đánh giá nhanh theo CN-58; không tự chọn 24 hoặc 48 làm guard số. | Chờ ngưỡng có thẩm quyền. |
| Q-05 | Hồ sơ/lịch/lần trình và các bội số | PCN-02 chỉ nói tập trung. Không chốt 1:1 hồ sơ/lịch, số kết quả dự báo một hồ sơ tham chiếu; không ép một phương án một hồ sơ; chưa chốt ánh xạ dòng bố trí–phân bổ. | Giữ association, bỏ con số chưa đủ nguồn trên hình; chờ chốt trước thiết kế dữ liệu. |
| Q-06 | Khoảng hở thang tải 100–120% | Giữ các điều kiện có nguồn, không tự gán một mức mới. | Chờ quyết định nghiệp vụ; không đổi P1. |
| Q-07 | Công thức ngân sách và trường hợp biên | Giữ ngưỡng QT-51, PM tự điều chỉnh/xin PMO hoặc chuyển CEO; công thức chưa có đủ căn cứ. | Chờ công thức/đơn vị và trường hợp ngân sách còn lại ≤0. |
| Q-08 | V10 dự báo một phần/danh sách nhu cầu rỗng | Bản sơ bộ dừng dự báo chính thức khi chưa đủ cơ sở; chỉ công bố kết quả tạm và yêu cầu bổ sung. Không tự suy cầu =0. | Chờ duyệt nếu muốn áp dụng dự báo theo từng phần đủ dữ liệu. |

| Q-09 | Điều kiện chuyển thông tin V10 | I.3.9 bước 7 có điều kiện thiếu/dư hoặc khác kỳ trước; I.1.3.10/CN-121 giao RM cân nhắc theo mức ảnh hưởng/quy định. Giữ quyết định RM, dẫn cả hai. | Chờ chốt bắt buộc chuyển hay căn cứ cân nhắc; đính chính audit cũ, không gọi là quy tắc tự đặt. |

## Nguồn và thay đổi

Baseline: I FINAL, Outline; danh mục mã theo HD-PCCN. Bài thành viên là đầu vào; audit/decision cũ là tài liệu hỗ trợ, không phải phê duyệt. Dùng PR cd09aa5 và nguồn bổ sung main 3a5ef26. Không thay đổi các file này.
Bản sao mới thay đổi: chuẩn hóa Summary/actor/CN; bảng sửa 4 cột theo vùng; II.3 bổ sung ngữ nghĩa giai đoạn, điều kiện miễn trừ và hạn xác nhận; V10 viết lại D/AD; dựng DOCX tổng hợp với vị trí chờ. Đây là bản trình duyệt; “chuẩn hóa theo nguồn” không có nghĩa nhóm đã phê duyệt những lựa chọn còn mở.

## Căn cứ và phân loại khi bàn giao

| Nhận định | Loại | Bằng chứng / cách sử dụng |
|---|---|---|
| Tên bốn mục II và ba tiểu mục II.4 | Fact | Outline bài thảo luận.docx, phần II. Giữ nguyên tên và thứ tự; không đổi tên II.1 theo cách gọi tắt trong trao đổi. |
| 9 vùng, 28 UC, bộ UC trọng tâm hiện có | Fact | HD-PCCN §1 và §5; đối chiếu các bài thành viên. Không đổi mã hoặc tự thay UC cá nhân V3/V8. |
| PMO có việc tại V4 dù bảng actor thiếu V4 | Conflict | I FINAL I.1.2 so với CN-37/43; giữ hành vi có nguồn và chờ Q-01 trước sửa baseline. |
| Điều kiện chuyển thông tin V10 có trong I FINAL | Conflict | I.3.9 bước 7 so với I.1.3.10/CN-121. Đính chính nhận định audit cũ cho rằng điều kiện khác kỳ trước hoàn toàn không có nguồn; Q-09 cần quyết định cách áp dụng. |
| Cấu trúc lớp chung và thuộc tính suy ra từ dữ liệu cần lưu | Inference | Là mô hình hóa từ CN/UC, không phải văn bản nghiệp vụ mới. Đối chiếu danh mục lớp và quan hệ trong II.3; bội số thiếu căn cứ được để trống. |
| Đổi UC cá nhân, chốt bội số, dự báo một phần, ngưỡng/công thức còn mở | Proposal | Q-02–Q-08; chưa coi là quyết định nhóm. |
| Trạng thái nhóm đã duyệt các đề xuất audit cũ | Unverified | Không có xác nhận duyệt riêng trong nguồn đã đọc. Bản sơ bộ giữ lựa chọn hiện hành và tách các điểm chờ. |
| Nguồn V8 và V9 bổ sung đã truy cập được | Fact | Main 3a5ef26: ba PNG V8 có mxfile gốc nhúng (3 trang), AD V9 “4. Activity Diagram.drawio”. Đã đọc cấu trúc thực, không kết luận thiếu nguồn chỉnh sửa. |
| Nguồn AD V4 dạng chỉnh sửa | Unverified | Hiện chỉ trích được hình AD trong V4 - Phần II.docx; giữ hình đã đạt, chưa tìm thấy file drawio riêng trong nguồn đọc được. Không tạo lớp vỏ hình ảnh rồi gọi là nguồn chỉnh sửa. |

Nguồn đã dùng: `Outline bài thảo luận.docx`; `[PTTKHT] I - PHÂN TÍCH YÊU CẦU FINAL.docx`; hai hướng dẫn `[PTTKHT] HOÀN THIỆN MỤC II - PHÂN TÍCH (THIẾT KẾ LOGIC).md` (HD-PCCN) và bản `(1).md` (HD-MAU); các bài V2a/V2b, V3, V4, NV05, V6, MNV7, MNV8, V9; artifact PR #1 và independent review đã có. Audit/decision log là nguồn hỗ trợ kiểm tra, không thay I FINAL/Outline và không chứng minh đã được phê duyệt.

Điểm cần ưu tiên duyệt để bước sang thiết kế: Q-05 (bội số/lần trình), Q-07 (tính ngân sách), Q-08 và Q-09 (V10). Q-03 chỉ cần chốt nếu muốn đổi bài cá nhân. Các bảng sửa khác có thể giao thành viên làm ngay theo nguồn.
