from pathlib import Path
from copy import deepcopy
import io,json,re,shutil,subprocess
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION_START,WD_ORIENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image

R=Path(__file__).resolve().parent.parent
D=json.loads((R/'_cong_cu/catalogue.json').read_text())
M=json.loads((R/'_cong_cu/domain_model.json').read_text())
V=json.loads((R/'_cong_cu/v10.json').read_text())
OUT=R/'BAO_CAO';OUT.mkdir(exist_ok=True)

def p(doc,text='',bold=False,style=None):
 x=doc.add_paragraph(style=style);r=x.add_run(text);r.bold=bold;return x
BREAKS=set()
def h(doc,text,level=2):
 x=doc.add_heading(text,level=level)
 if id(doc) in BREAKS:x.paragraph_format.page_break_before=True;BREAKS.remove(id(doc))
 return x
def page(doc):BREAKS.add(id(doc))
def table(doc,heads,rows,widths=None,size=10.5):
 t=doc.add_table(rows=1,cols=len(heads));t.style='Table Grid';t.autofit=False
 for c,s in zip(t.rows[0].cells,heads):c.text=str(s)
 for row in rows:
  cells=t.add_row().cells
  for c,s in zip(cells,row):c.text=str(s)
 if widths:
  for row in t.rows:
   for c,w in zip(row.cells,widths):c.width=Cm(w)
 for i,row in enumerate(t.rows):
  pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
  if not i:
   pr.append(OxmlElement('w:tblHeader'))
  for c in row.cells:
   if not i:
    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'EAEDEF');c._tc.get_or_add_tcPr().append(sh)
   for pp in c.paragraphs:
    pp.paragraph_format.space_after=Pt(3);pp.paragraph_format.space_before=Pt(2)
    pp.paragraph_format.line_spacing=1.05
    for rr in pp.runs:rr.font.name='Times New Roman';rr.font.size=Pt(size);rr.bold=(i==0)
 p(doc)
 return t
def picture(doc,filename,caption,maxw=16.4,maxh=21.2):
 im=Image.open(filename);w,hh=im.size;scale=min(maxw/w,maxh/hh)
 pp=doc.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
 pp.paragraph_format.space_after=Pt(3);pp.paragraph_format.keep_with_next=True
 pp.add_run().add_picture(str(filename),width=Cm(w*scale),height=Cm(hh*scale))
 pp=doc.add_paragraph(caption,style='Caption');pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
 pp.paragraph_format.keep_with_next=False
def setup():
 doc=Document();s=doc.sections[0];s.page_width=Cm(21);s.page_height=Cm(29.7)
 for k in ['top_margin','bottom_margin','left_margin','right_margin']:setattr(s,k,Cm(2.286))
 s.header_distance=Cm(1);s.footer_distance=Cm(1)
 normal=doc.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(12)
 normal.paragraph_format.space_after=Pt(6);normal.paragraph_format.line_spacing=1.12
 for k,z in [('Title',18),('Heading 1',16),('Heading 2',14),('Heading 3',13),('Heading 4',12)]:
  st=doc.styles[k];st.font.name='Times New Roman';st.font.size=Pt(z);st.font.color.rgb=RGBColor(0,0,0)
  st.paragraph_format.keep_with_next=True;st.paragraph_format.space_before=Pt(10);st.paragraph_format.space_after=Pt(6)
 doc.styles['Caption'].font.name='Times New Roman';doc.styles['Caption'].font.size=Pt(10)
 foot=s.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.RIGHT
 foot.add_run('PTTKHTTT • Phần II sơ bộ | ')
 fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');foot._p.append(fld)
 doc.core_properties.title='PTTKHTTT — Phần II sơ bộ'
 doc.core_properties.subject='Tiếp nối I FINAL; bản trình duyệt, chưa thay baseline'
 doc.core_properties.author='Nhóm PTTKHTTT'
 return doc
def orient(doc,landscape):
 s=doc.add_section(WD_SECTION_START.NEW_PAGE)
 s.orientation=WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
 s.page_width=Cm(29.7 if landscape else 21);s.page_height=Cm(21 if landscape else 29.7)
 for k in ['top_margin','bottom_margin','left_margin','right_margin']:setattr(s,k,Cm(1.6 if landscape else 2.286))
def v10_spec(doc,u,titlelevel=3):
 h(doc,u['id']+' — '+u['name'],titlelevel)
 table(doc,['Trường','Nội dung'],[(label,u[k]) for k,label in [('actor','Actor chính'),('secondary','Actor phụ'),('goal','Mục tiêu'),('trigger','Trigger'),('pre','Tiền điều kiện'),('post','Hậu điều kiện'),('inputs','Đầu vào'),('outputs','Đầu ra'),('cn','Truy vết')]], [3.2,13.2])
 h(doc,'Luồng chính',4);table(doc,['Bước','Người thực hiện / hỗ trợ','Xử lý'],u['steps'],[1.2,3.6,11.6])
 h(doc,'Luồng thay thế / ngoại lệ',4);table(doc,['Mã','Bước','Điều kiện','Xử lý'],u['alternatives'],[1,1.2,5.2,9])
 page(doc);h(doc,'Activity Diagram — '+u['id'],3)
 picture(doc,R/'II.2_V10'/u['ad'],'AD '+u['id']+' — đối chiếu cùng UC Description.',maxh=21.3)

def extract_v4():
 dest=R/'II.2_UCD_cap_vung/V4_UC-03.3_Dac_ta.json'
 if dest.exists():return json.loads(dest.read_text())
 b=subprocess.run(['git','-C','review-copy','show','HEAD:V4 - Phần II.docx'],check=True,capture_output=True).stdout
 src=Document(io.BytesIO(b));items=[];active=False
 for el in src.element.body:
  if el.tag==qn('w:p'):
   text=''.join(el.itertext()) if False else ''.join(t.text or '' for t in el.iter(qn('w:t')))
   if text.startswith('3. Use Case Description'):active=True;continue
   if text.startswith('4. Activity Diagram'):break
   if active and text.strip():items.append(dict(kind='p',text=text))
  elif active and el.tag==qn('w:tbl'):
   rows=[]
   for row in el.findall(qn('w:tr')):
    rows.append(['\n'.join(''.join(t.text or '' for t in pp.iter(qn('w:t'))) for pp in c.findall(qn('w:p'))) for c in row.findall(qn('w:tc'))])
   items.append(dict(kind='table',rows=rows))
 dest.write_text(json.dumps(items,ensure_ascii=False,indent=2));return items

def main():
 doc=setup();h(doc,'II. PHÂN TÍCH (THIẾT KẾ LOGIC)',1)
 p(doc,'BẢN SƠ BỘ ĐỂ NHÓM XEM XÉT • 22/10/2026',True)
 p(doc,'Tài liệu tiếp nối “[PTTKHT] I - PHÂN TÍCH YÊU CẦU FINAL.docx”, giữ cấu trúc của “Outline bài thảo luận.docx”. Các mục chờ hoàn thiện có mã UC và người phụ trách; các lựa chọn nghiệp vụ còn mở được tách trong CHOT_NOI_DUNG_CHUNG.md. Không thay đổi Phần I.')
 h(doc,'II.1. Phạm vi hệ thống công nghệ',2)
 p(doc,'Hệ thống hỗ trợ quản lý và điều phối nguồn lực dự án: xác định nhu cầu, quản lý năng lực, tìm kiếm và đánh giá phù hợp, đánh giá khả năng tham gia, xây dựng phương án, xử lý xung đột, phê duyệt, đánh giá chi phí và theo dõi dự báo. Sáu actor là PM, RM, Nguồn lực, Tài chính, PMO/Quản lý danh mục và CEO/Managing Director.')
 picture(doc,R/'II.1_Use_Case_Tong_Quat/II1_UC_Tong_Quat.png','Hình II.1-1. Sơ đồ ca sử dụng tổng quát.',maxh=12.8)
 p(doc,'PMO tham gia V4 ở việc phê duyệt miễn trừ và điều chỉnh kết quả theo CN-37/43. V10 do RM thực hiện, PM cung cấp/xác nhận nhu cầu và tra cứu theo CN-114/123. Các bàn giao liên vùng là luồng thông tin, không mặc định là quan hệ include.')
 page(doc);h(doc,'Phân cấp chức năng và danh sách chức năng con',3)
 picture(doc,R/'I_Phan_ra_chuc_nang/Phan_ra_chuc_nang.png','Hình II.1-2. Phân cấp 9 vùng và 28 UC; mã và tên giữ theo HD-PCCN §1.',maxh=21.5)
 page(doc);h(doc,'Danh mục UC và phạm vi đặc tả',3)
 p(doc,'Giữ 28 mã UC. Mười hai UC dưới đây có vị trí đặc tả chi tiết và AD theo bộ lựa chọn hiện có. Các UC còn lại có FDS tóm tắt tại đúng vùng trong II.2. Mức đặc tả cuối cùng tuân thủ yêu cầu học phần; bản sơ bộ không cắt giảm sản phẩm II.4.')
 table(doc,['Vùng / UC','Tên chức năng con','CN I FINAL','Đặc tả'],[[u['region']+' / '+u['id'],u['name'],u['cn'],'Trọng tâm' if u['core'] else 'Tóm tắt'] for u in D['ucs']],[2.9,6.9,4.1,2.5])
 h(doc,'Nguồn dùng chung',3)
 p(doc,'Baseline nghiệp vụ: I FINAL; cấu trúc/đầu ra: Outline; mã và tên UC: HD-PCCN §1. Mô tả thành viên và artifact PR là đầu vào tích hợp, không tự trở thành baseline. FDS Summary chuẩn hóa nằm tại II.1_Use_Case_Tong_Quat/Danh_muc_FDS_Summary.md; các bảng trong II.2 dùng cùng danh mục này.')
 page(doc);h(doc,'II.2. Mô hình hóa chức năng của hệ thống công nghệ',2)
 p(doc,'Mỗi vùng gồm UCD chi tiết, FDS cho các UC và vị trí AD của UC trọng tâm. Những D/AD còn phải sửa được giữ đúng mã và ghi chờ hoàn thiện; yêu cầu cụ thể nằm trong BANG_SUA/Vx_Yeu_cau_sua.md. V4 giữ đặc tả và AD hiện có; V10 dùng bản đã sửa trong gói này.')
 v4=extract_v4()
 for idx,(group,name,v,subs) in enumerate(D['regions'],1):
  if idx>1:page(doc)
  h(doc,f'II.2.{idx}. {v} — {name}',3)
  p(doc,'Phụ trách: '+D['owners'][v]+'.')
  png=R/('II.2_V10' if v=='V10' else 'II.2_UCD_cap_vung')/('UCD_'+group+'.png')
  picture(doc,png,'Hình II.2-'+str(idx)+'. UCD vùng '+v+' ('+group+').',maxh=9.4)
  us=[u for u in D['ucs'] if u['region']==v]
  short=[u for u in us if not u['core']]
  if short:
   h(doc,'FDS tóm tắt — các UC còn lại',4)
   for u in short:
    h(doc,u['id']+' — '+u['name'],4)
    table(doc,['Thành phần','Mô tả'],[['Actor',u['actor']],['Đầu vào',u['input']],['Phạm vi xử lý',u['scope']],['Kết quả',u['output']],['Nguồn I FINAL','CN-'+u['cn']]],[3.1,13.3])
  for u in [u for u in us if u['core']]:
   page(doc)
   if v=='V10':
    v10_spec(doc,next(x for x in V['specs'] if x['id']==u['id']));continue
   h(doc,u['id']+' — '+u['name'],3)
   if v=='V4':
    p(doc,'Giữ UC Description từ “V4 - Phần II.docx” §3. Chỉ đồng bộ tên lớp theo II.3; nhánh phản hồi CN-46 khi cạn nguồn ứng viên chờ hoàn thiện cùng V2.')
    for item in v4:
     if item['kind']=='p':h(doc,re.sub(r'^3\.\d+\.?\s*','',item['text']),4)
     else:
      rows=item['rows'];table(doc,rows[0],rows[1:],size=10.5)
    page(doc);h(doc,'Activity Diagram — UC-03.3',3)
    picture(doc,R/'II.2_UCD_cap_vung/AD_UC-03.3_giu_lai.png','Hình II.2-AD03.3. Giữ AD từ bài V4; bản hiện có là hình trong DOCX.',maxh=21)
   else:
    p(doc,'[Chờ hoàn thiện theo phân công] — UC Description/FDS chi tiết và AD. Dùng bài hiện có để sửa theo bảng yêu cầu của '+v+'; chưa coi bản đang lỗi là sản phẩm đã chốt.',True)
    table(doc,['Thành phần giữ đúng mã','Nội dung / trạng thái'],[['Phụ trách',u['owner']],['Actor',u['actor']],['Đầu vào',u['input']],['Mục tiêu / phạm vi',u['scope']],['Kết quả cần đạt',u['output']],['Nguồn','I FINAL CN-'+u['cn']],['Trigger, tiền/hậu điều kiện','[Chờ hoàn thiện theo phân công]'],['Luồng chính, thay thế/ngoại lệ, BR','[Chờ hoàn thiện theo phân công] — đối chiếu BANG_SUA/'+v+'_Yeu_cau_sua.md'],['Activity Diagram '+u['id'],'[Chờ hoàn thiện theo phân công] — đặt AD đã sửa tại đây; D và AD phải có cùng nhánh, actor và kết thúc.']],[4,12.4])
  if v=='V10':
   page(doc);h(doc,'Quy tắc và bàn giao V10',3)
   table(doc,['Nguồn','Nội dung'],V['rules'],[4.3,12.1])
   table(doc,['Nơi nhận','Thông tin theo CN-122'],[['V2','Khả năng cung ứng; khoảng thiếu hoặc dư.'],['V6','Lịch phân bổ hiện tại; nguồn cung còn lại.'],['V7','Thiếu/dư và tình trạng cung–cầu.'],['V8','Tổng hợp cung–cầu và kết quả dự báo.']],[2.2,14.2])
   p(doc,'Quan hệ với II.3: KetQuaDuBao tổng hợp TongHopNguonCung, NhuCauDuBao và DongDoiChieuCungCau. Tham chiếu hồ sơ, lịch, cam kết dùng chung; không tạo bản sao hồ sơ/lịch gốc. Các lựa chọn Q-08/Q-09 vẫn chờ xác nhận trước khi chốt quy tắc triển khai.')
 page(doc);h(doc,'II.3. Mô hình hóa cấu trúc tĩnh của hệ thống công nghệ',2)
 p(doc,'Mô hình lớp miền mô tả các đối tượng và quan hệ dữ liệu phục vụ UC ở II.2. Tên lớp dùng thống nhất giữa các vùng; các hình phân tách chỉ là các góc nhìn của cùng mô hình, không phải các mô hình dữ liệu độc lập.')
 p(doc,'Hình tổng quan chỉ trình bày các lớp trung tâm. Các hình chi tiết hiển thị một số thuộc tính để dễ đọc; danh mục sau hình liệt kê toàn bộ thuộc tính. Thuộc tính bắt đầu bằng “/” là giá trị suy dẫn. Lớp nền xám là lớp tham chiếu từ vùng khác. Đường không ghi bội số biểu thị bội số chưa được chốt; không mặc định thành 1:1.')
 p(doc,'Phương án/dòng bố trí khác phân bổ lịch; phân bổ cứng gắn với kết quả được duyệt. Kết luận khả năng tham gia có căn cứ và hạn xác nhận. Miễn trừ có điều kiện được miễn, lý do, người và thời điểm quyết định. Dự báo không sở hữu lại hồ sơ năng lực hoặc lịch nguồn lực.')
 views=[('II3_Tong_quan','Tổng quan các lớp miền trung tâm'),('II3_A1_Nhu_cau_Nang_luc','Dự án, nhu cầu và năng lực'),('II3_A2_Phu_hop','Tìm kiếm và đánh giá phù hợp'),('II3_B1_Lich_Phuong_an','Khả năng tham gia, lịch và phương án'),('II3_B2_Xung_dot','Cân đối và xử lý xung đột'),('II3_C1_Phe_duyet','Rà soát và phê duyệt'),('II3_C2_Chi_phi','Chi phí và ngân sách'),('II3_D_Du_bao','Theo dõi và dự báo')]
 orient(doc,True)
 for i,(stem,title) in enumerate(views,1):
  if i>1:page(doc)
  h(doc,'II.3 — '+title,3)
  picture(doc,R/'II.3_Domain_Class_Diagram'/(stem+'.png'),f'Hình II.3-{i}. {title}.',maxw=26.3,maxh=15.4)
 orient(doc,False);h(doc,'Danh mục lớp và thuộc tính miền',3)
 for v in D['owners']:
  h(doc,v+' — dữ liệu miền',4)
  table(doc,['Lớp','Thuộc tính'],[[c,', '.join(attrs)] for c,attrs in M['classes'].items() if M['packages'][c]==v],[5.4,11],size=10.5)
 page(doc);h(doc,'II.4. Mô hình hóa hành vi của hệ thống công nghệ',2)
 p(doc,'Các sản phẩm dưới đây sẽ dựa trên UC và mô hình lớp tại II.2–II.3. Mỗi vùng tiếp tục hoàn thiện theo bài cá nhân và quy trình tích hợp; bản sơ bộ giữ đủ ba loại sơ đồ theo outline.')
 h(doc,'II.4.1. Sơ đồ trạng thái',3)
 p(doc,'Đối tượng có hành vi/vòng đời phức tạp: [Chờ hoàn thiện theo phân công]. Chốt tên trạng thái và sự kiện từ D/AD trước khi chèn sơ đồ. Các vị trí dưới đây cần thành viên xác nhận phạm vi đối tượng thực hiện.')
 table(doc,['Vùng / đối tượng liên quan','Sản phẩm chờ'],[['V2 — NhuCauNguonLuc','[Chờ hoàn thiện theo phân công] — thống nhất trạng thái nhu cầu.'],['V5–V6 — KetLuanKhaNangThamGia; PhuongAnBoTri','[Chờ hoàn thiện theo phân công] — có điều kiện/hạn xác nhận; xây dựng, rà soát.'],['V7–V8 — DiemXungDot; HoSoTrinhDuyet; QuyetDinhPheDuyet','[Chờ hoàn thiện theo phân công] — xử lý/chuyển cấp, yêu cầu bổ sung, quyết định.'],['Các vùng còn lại','[Chờ hoàn thiện theo phân công] — xác định đối tượng có vòng đời phức tạp theo bài cá nhân.']],[6,10.4])
 page(doc);h(doc,'II.4.2. Sơ đồ giao tiếp',3)
 p(doc,'Sự kiện/hoạt động truy vấn dữ liệu của đối tượng: [Chờ hoàn thiện theo phân công]. Giữ các vị trí theo mã UC trọng tâm dưới đây; chọn các sự kiện truy vấn có trong đặc tả, không tự thêm UC hoặc thao tác mới.')
 table(doc,['Vùng / UC trọng tâm','Sơ đồ giao tiếp — truy vấn'],[[v+', '+', '.join(u['id'] for u in D['ucs'] if u['region']==v and u['core']),'[Chờ hoàn thiện theo phân công]'] for v in D['owners']],[7,9.4])
 page(doc);h(doc,'II.4.3. Sơ đồ tuần tự/trình tự',3)
 p(doc,'Sự kiện/hoạt động thay đổi dữ liệu của đối tượng: [Chờ hoàn thiện theo phân công]. Mỗi sơ đồ cần bám một luồng D/AD đã ổn định, dùng lớp miền chung và đúng người có thẩm quyền quyết định.')
 table(doc,['Vùng / UC trọng tâm','Sơ đồ tuần tự — cập nhật'],[[v+', '+', '.join(u['id'] for u in D['ucs'] if u['region']==v and u['core']),'[Chờ hoàn thiện theo phân công]'] for v in D['owners']],[7,9.4])
 doc.save(OUT/'PTTKHTTT_PHAN_II_SO_BO.docx')
 standalone=setup();h(standalone,'V10 — THEO DÕI VÀ DỰ BÁO NGUỒN LỰC',1)
 p(standalone,'Bản sơ bộ để duyệt; mã UC giữ nguyên. Nguồn: I FINAL I.1.3.10, I.2.1.9, I.3.9, QT-53–57 và PCN-03. Q-08/Q-09 chưa được coi là quy tắc đã duyệt.')
 picture(standalone,R/'II.2_V10/UCD_UC-09.png','UCD vùng UC-09.',maxh=12)
 for u in V['specs']:page(standalone);v10_spec(standalone,u,2)
 page(standalone);h(standalone,'Quy tắc và đối chiếu D–AD',2);table(standalone,['Nguồn','Nội dung'],V['rules'],[4,12.4])
 table(standalone,['Mã','Tình huống','Kết quả cần có'],V['tests'],[1.2,5.4,9.8])
 h(standalone,'Điểm chờ quyết định',2)
 p(standalone,'Q-08: dự báo một phần khi cung thiếu và xác nhận kỳ không phát sinh nhu cầu; bản sơ bộ không suy cầu bằng 0. Q-09: điều kiện chuyển trong I.3.9 bước 7 là bắt buộc hay căn cứ để RM cân nhắc theo I.1.3.10/CN-121. Ngưỡng “thay đổi đáng kể” chưa được định lượng trong nguồn.')
 standalone.save(OUT/'V10_UC_DESCRIPTION_VA_AD.docx')
 print('Saved main + V10 DOCX')

if __name__=='__main__':main()
