const fs=require('fs'),path=require('path');
const sharp=require(process.env.CODEX_PRIMARY_RUNTIME_ROOT?process.env.CODEX_PRIMARY_RUNTIME_ROOT+'/dependencies/node/node_modules/sharp':'sharp');
const ROOT=path.resolve(__dirname,'..');const data=JSON.parse(fs.readFileSync(ROOT+'/_cong_cu/catalogue.json'));
const model=JSON.parse(fs.readFileSync(ROOT+'/_cong_cu/domain_model.json'));
const cname=s=>s.replace(/([a-z])([A-Z])/g,'$1 $2').split(' ').reduce((a,w)=>{let i=a.length-1;if(a[i].length+w.length>20)a.push(w);else a[i]+=(a[i]?' ':'')+w;return a;},['']).map(x=>x.replace(/ /g,'')).join('<BR/>');
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const wrap=(s,n=30)=>{let out=[],l='';for(const w of s.split(/\s+/)){if(l.length+w.length+1>n){out.push(l);l=w;}else l+=(l?' ':'')+w;}if(l)out.push(l);return out;};
class Scene{
 constructor(name,w,h,title){this.name=name;this.title=title;this.w=w;this.h=h;this.nodes=[];this.edges=[];this.svg=[];if(title)this.text(title,w/2,24,18,true);}
 text(s,x,y,size=15,bold=false,anchor='middle'){const ls=String(s).split('\n');this.svg.push(`<text x="${x}" y="${y}" text-anchor="${anchor}" font-family="DejaVu Sans,Arial" font-size="${size}" ${bold?'font-weight="bold"':''}>${ls.map((l,i)=>`<tspan x="${x}" dy="${i?size*1.25:0}">${esc(l)}</tspan>`).join('')}</text>`);}
 node(id,label,x,y,w,h,shape='box',fill='white',size=15){this.nodes.push({id,label,x,y,w,h,shape,fill,size});let st=`fill="${fill}" stroke="#242424" stroke-width="1.4"`;
  if(shape==='diamond')this.svg.push(`<polygon points="${x+w/2},${y} ${x+w},${y+h/2} ${x+w/2},${y+h} ${x},${y+h/2}" ${st}/>`);
  else if(shape==='start'||shape==='end'){this.svg.push(`<circle cx="${x+w/2}" cy="${y+h/2}" r="${w/2}" fill="${shape==='start'?'#222':'white'}" stroke="#222" stroke-width="1.5"/>`);if(shape==='end')this.svg.push(`<circle cx="${x+w/2}" cy="${y+h/2}" r="${w/2-5}" fill="#222"/>`);}
  else this.svg.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" ${shape==='action'?'rx="9"':''} ${st}/>`);
  if(label){const lines=label.split('\n');this.text(label,x+w/2,y+h/2-(lines.length-1)*size*.625+size*.34,size,shape==='heading');}return id;}
 edge(a,b,points,label='',arrow=true){const ns=Object.fromEntries(this.nodes.map(n=>[n.id,n]));let aa=ns[a],bb=ns[b];if(!points)points=[[aa.x+aa.w/2,aa.y+aa.h],[bb.x+bb.w/2,bb.y]];this.edges.push({a,b,points,label,arrow});const pp=points.map(p=>p.join(',')).join(' ');this.svg.push(`<polyline points="${pp}" fill="none" stroke="#333" stroke-width="1.5" ${arrow?'marker-end="url(#arrow)"':''}/>`);if(label){const k=Math.floor((points.length-1)/2);this.text(label,points[k][0]+8,points[k][1]-8,12,false,'start');}}
 async save(folder){fs.mkdirSync(folder,{recursive:true});let svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${this.w}" height="${this.h}" viewBox="0 0 ${this.w} ${this.h}"><defs><marker id="arrow" markerWidth="9" markerHeight="7" refX="8" refY="3.5" orient="auto"><path d="M0,0 L8,3.5 L0,7" fill="none" stroke="#333"/></marker></defs><rect width="100%" height="100%" fill="white"/>${this.svg.join('')}</svg>`;fs.writeFileSync(folder+'/'+this.name+'.svg',svg);await sharp(Buffer.from(svg)).png().toFile(folder+'/'+this.name+'.png');
  let cells=['<mxCell id="0"/><mxCell id="1" parent="0"/>'];if(this.title)cells.push(`<mxCell id="title" value="${esc(this.title)}" vertex="1" parent="1" style="text;html=0;align=center;fontStyle=1;fontSize=18;"><mxGeometry x="20" y="4" width="${this.w-40}" height="35" as="geometry"/></mxCell>`);if(this.name.startsWith('AD_')){const xs=this.name.endsWith('09.1')?[20,350,730,1060]:[20,470,930];xs.forEach((x,i)=>cells.push(`<mxCell id="lane${i}" edge="1" parent="1" style="endArrow=none;strokeColor=#AAAAAA;"><mxGeometry relative="1" as="geometry"><mxPoint x="${x}" y="87" as="sourcePoint"/><mxPoint x="${x}" y="${this.h-30}" as="targetPoint"/></mxGeometry></mxCell>`));}for(const n of this.nodes){let style='whiteSpace=wrap;html=0;fontFamily=Arial;fontSize='+n.size+';fillColor='+n.fill+';strokeColor=#242424;';if(n.shape==='diamond')style+='rhombus;';else if(n.shape==='start')style+='ellipse;fillColor=#222222;';else if(n.shape==='end')style+='shape=doubleEllipse;fillColor=#222222;';else if(n.shape==='action')style+='rounded=1;';else if(n.shape==='heading')style+='fontStyle=1;';cells.push(`<mxCell id="${n.id}" value="${esc(n.label)}" style="${style}" vertex="1" parent="1"><mxGeometry x="${n.x}" y="${n.y}" width="${n.w}" height="${n.h}" as="geometry"/></mxCell>`);}
  this.edges.forEach((e,i)=>{cells.push(`<mxCell id="e${i}" value="${esc(e.label)}" edge="1" source="${e.a}" target="${e.b}" parent="1" style="endArrow=${e.arrow?'open':'none'};rounded=0;html=0;fontFamily=Arial;fontSize=12;labelBackgroundColor=#FFFFFF;"><mxGeometry relative="1" as="geometry"><Array as="points">${e.points.slice(1,-1).map(p=>`<mxPoint x="${p[0]}" y="${p[1]}"/>`).join('')}</Array></mxGeometry></mxCell>`);});
  fs.writeFileSync(folder+'/'+this.name+'.drawio',`<mxfile host="app.diagrams.net"><diagram name="${this.name}"><mxGraphModel pageWidth="${this.w}" pageHeight="${this.h}"><root>${cells.join('')}</root></mxGraphModel></diagram></mxfile>`);
 }
}
async function tree(){let s=new Scene('Phan_ra_chuc_nang',1240,1500,'Phân cấp chức năng — 9 vùng và 28 UC chi tiết');s.node('root','Hệ thống quản lý và điều phối nguồn lực dự án\nLạc Việt Consulting',300,50,640,70,'heading','#edf1f5',19);
 for(let i=0;i<data.regions.length;i++){let[c,n,v,subs]=data.regions[i];let col=i%3,row=Math.floor(i/3),x=20+col*410,y=175+row*430;s.node('r'+i,c+' — '+v+'\n'+wrap(n,32).join('\n'),x,y,380,90,'heading','#f1f3f5',17);for(let j=0;j<subs.length;j++){let[uc,un]=subs[j];let yy=y+108+j*70;s.node(uc,uc+'\n'+wrap(un,39).join('\n'),x+20,yy,360,62,'box','white',15);s.edge('r'+i,uc,[[x+10,y+90],[x+10,yy+31],[x+20,yy+31]],'',false);} }
 // Mỗi nhóm là một nhánh của cấp 0; không kéo đường qua các UC con.
 s.text('Cấp 0: hệ thống     •     Cấp 1: UC-01…UC-09     •     Cấp 2: 28 UC chi tiết',620,1465,16);
 for(let i=0;i<9;i++){let col=i%3,row=Math.floor(i/3),x=20+col*410,y=175+row*430;let rail=10+col*410;s.edge('root','r'+i,[[620,120],[620,140],[rail,140],[rail,y+45],[x,y+45]],'',false);}
 await s.save(ROOT+'/I_Phan_ra_chuc_nang');}
async function v10(){
 let s=new Scene('AD_UC-09.1',1080,1550,'UC-09.1 — Tổng hợp và phân tích cung – cầu nguồn lực');
 s.node('rm','RM',20,45,330,42,'heading','#f1f3f5');s.node('sys','Hệ thống',350,45,380,42,'heading','#f1f3f5');s.node('pm','PM',730,45,330,42,'heading','#f1f3f5');
 s.svg.push('<path d="M20 87V1520 M350 87V1520 M730 87V1520 M1060 87V1520" fill="none" stroke="#aaa"/>');
 s.node('start','',180,105,22,22,'start');s.node('trigger','Mở lần tổng hợp theo kỳ tuần\nhoặc thay đổi đáng kể',55,155,270,60,'action');s.edge('start','trigger');
 s.node('fork','',75,245,870,6,'box','#222');s.edge('trigger','fork',[[190,215],[190,245]]);
 s.node('supply','Tổng hợp nguồn cung, lịch\nvà các cam kết hiện có',55,285,270,65,'action');s.node('demand','Cung cấp và xác nhận nhu cầu\ntheo dự án, vai trò, kỹ năng, thời gian',750,285,285,65,'action');s.edge('fork','supply',[[190,251],[190,285]]);s.edge('fork','demand',[[890,251],[890,285]]);
 s.node('join','',75,385,870,6,'box','#222');s.edge('supply','join',[[190,350],[190,385]]);s.edge('demand','join',[[890,350],[890,385]]);
 s.node('enough','Đủ cơ sở\nvề nguồn cung?',105,430,175,90,'diamond', 'white',14);s.edge('join','enough',[[190,391],[190,430]]);
 s.node('missing','Ghi phần thiếu, yêu cầu bổ sung;\nlưu kết quả tổng hợp tạm,\nchưa lập dự báo chính thức',390,445,305,78,'action');s.edge('enough','missing',[[280,475],[390,475]],'Chưa đủ');s.node('endmissing','',860,467,27,27,'end');s.edge('missing','endmissing',[[695,480],[860,480]]);
 s.node('available','Xác định nguồn cung có thể đáp ứng\nsau khi trừ đủ phần cam kết',55,575,270,65,'action','white',14);s.edge('enough','available',[[190,520],[190,575]],'Đủ');
 s.node('call','Lập dự báo và đối chiếu\n(thực hiện UC-09.2)',390,685,305,65,'action');s.edge('available','call',[[190,640],[190,665],[540,665],[540,685]]);
 s.node('usable','Có kết quả\nđủ cơ sở?',450,790,180,90,'diamond','white',14);s.edge('call','usable');s.node('nocert','Ghi nhận chưa đủ cơ sở;\nchuyển RM xác nhận/bổ sung',390,930,305,70,'action');s.edge('usable','nocert',[[630,835],[710,835],[710,965],[695,965]],'Chưa');s.node('endnocert','',650,1040,27,27,'end');s.edge('nocert','endnocert',[[540,1000],[540,1054],[650,1054]]);
 s.node('analyse','Phân tích thiếu/dư theo số lượng,\nvai trò, kỹ năng và thời điểm\n(nếu đủ: ghi nhận đáp ứng)',45,930,290,82,'action');s.edge('usable','analyse',[[540,880],[540,905],[190,905],[190,930]],'Có');
 s.node('total','Tổng hợp kết quả; tham khảo V9\nchỉ làm căn cứ bổ sung',45,1060,290,65,'action');s.edge('analyse','total');
 s.node('send','RM quyết định\nchuyển thông tin?',100,1170,185,90,'diamond','white',14);s.edge('total','send');
 s.node('deliver','Ghi quyết định và chuyển đúng\nnhóm thông tin cho V2, V6, V7, V8',390,1180,305,70,'action');s.edge('send','deliver',[[285,1215],[390,1215]],'Chuyển');
 s.node('keep','Lưu quyết định và kết quả;\nPM có thể tra cứu thông tin',385,1320,315,65,'action');s.edge('send','keep',[[190,1260],[190,1352],[385,1352]],'Theo dõi');s.edge('deliver','keep');
 s.node('end','',528,1440,27,27,'end');s.edge('keep','end');
 s.text('Kết thúc một lần chạy; trigger tuần/ngoài kỳ được mô tả trong FDS. V10 không quyết định cách bố trí.',540,1515,13);
 await s.save(ROOT+'/II.2_V10');
 s=new Scene('AD_UC-09.2',950,1480,'UC-09.2 — Dự báo cung – cầu nguồn lực');s.node('rm','RM',20,45,450,42,'heading','#f1f3f5');s.node('sys','Hệ thống',470,45,460,42,'heading','#f1f3f5');s.svg.push('<path d="M20 87V1445 M470 87V1445 M930 87V1445" fill="none" stroke="#aaa"/>');
 s.node('start','',675,105,22,22,'start');s.node('receive','Nhận cung có thể đáp ứng,\nnhu cầu và khoảng thời gian',550,155,285,65,'action');s.edge('start','receive');
 s.node('more','Còn nhu cầu\ncần xét?',140,265,180,85,'diamond','white',14);s.edge('receive','more',[[690,220],[690,240],[230,240],[230,265]]);
 s.node('basis','Xét trạng thái, mức chắc chắn,\nthời gian và phạm vi',75,395,310,65,'action');s.edge('more','basis',[[230,350],[230,395]],'Còn');
 s.node('eligible','Đủ cơ sở?',155,505,150,80,'diamond','white',14);s.edge('basis','eligible');
 s.node('tag','Gắn nhãn đã xác nhận/dự kiến;\nđưa nhu cầu vào tập dự báo',535,520,300,65,'action');s.edge('eligible','tag',[[305,545],[535,545]],'Đủ');
 s.node('exclude','Ghi lý do chưa đủ cơ sở;\nchưa đưa nhu cầu vào dự báo',530,635,310,65,'action');s.edge('eligible','exclude',[[230,585],[230,667],[530,667]],'Chưa đủ');
 s.node('next','Chuyển nhu cầu tiếp theo',545,750,285,50,'action');s.edge('tag','next',[[835,550],[875,550],[875,775],[830,775]]);s.edge('exclude','next');s.edge('next','more',[[690,800],[895,800],[895,250],[230,250],[230,265]],'Lặp');
 s.node('inputok','Có nhu cầu\nđủ cơ sở?',135,850,190,90,'diamond','white',14);s.edge('more','inputok',[[140,307],[45,307],[45,895],[135,895]],'Hết');
 s.node('nodemand','Ghi tình trạng đầu vào;\ntrả RM xác nhận cơ sở,\nkhông tự suy cầu bằng 0',530,855,310,80,'action');s.edge('inputok','nodemand',[[325,895],[530,895]],'Chưa có');s.node('endno','',870,880,27,27,'end');s.edge('nodemand','endno',[[840,895],[870,895]]);
 s.node('forecast','Lập dự báo cung và cầu\ntheo khoảng thời gian xác định',75,1000,310,65,'action');s.edge('inputok','forecast',[[230,940],[230,1000]],'Có');
 s.node('compare','Đối chiếu theo từng khoảng;\nxác định đáp ứng/thiếu/dư',75,1110,310,65,'action');s.edge('forecast','compare');
 s.node('record','Ghi kết quả, mức chắc chắn\nvà phần dữ liệu thiếu; trả 09.1',530,1220,310,70,'action');s.edge('compare','record',[[230,1175],[230,1198],[685,1198],[685,1220]]);
 s.node('end','',674,1350,27,27,'end');s.edge('record','end');s.text('Không dùng dữ liệu lịch sử, cơ hội kinh doanh hoặc chi phí V9 để dự báo (QT-57).',475,1435,13);
 await s.save(ROOT+'/II.2_V10');
}
async function classes(){const specs=[
 ['II3_Tong_quan','Các lớp miền trung tâm', ['DuAn','NhuCauNguonLuc','ViTriCanBoTri','NguonLuc','HoSoNangLuc','LichNguonLuc','PhanBoNguonLuc','KetQuaDanhGiaPhuHop','KetLuanKhaNangThamGia','PhuongAnBoTri','ChiTietBoTri','DiemXungDot','HoSoTrinhDuyet','QuyetDinhPheDuyet','DanhGiaChiPhi','KetQuaDuBao'],[],true],
 ['II3_A1_Nhu_cau_Nang_luc','A1 — Dự án, nhu cầu và năng lực',['V2','V3'],['PhuongAnBoTri'],false],
 ['II3_A2_Phu_hop','A2 — Tìm kiếm và đánh giá phù hợp',['V4'],['NhuCauNguonLuc','NguonLuc','KyNang'],false],
 ['II3_B1_Lich_Phuong_an','B1 — Lịch và phương án bố trí',['V5','V6'],['NguonLuc','ViTriCanBoTri','GiaiDoanDuAn'],false],
 ['II3_B2_Xung_dot','B2 — Cân đối và xử lý xung đột',['V7'],['PhuongAnBoTri','NguonLuc'],false],
 ['II3_C1_Phe_duyet','C1 — Phê duyệt phương án',['V8'],['PhuongAnBoTri','PhanBoNguonLuc','DanhGiaChiPhi','KetQuaDuBao'],false],
 ['II3_C2_Chi_phi','C2 — Chi phí và ngân sách',['V9'],['PhuongAnBoTri','DuAn'],false],
 ['II3_D_Du_bao','D — Theo dõi và dự báo',['V10'],['NguonLuc','NhuCauNguonLuc','PhanHoiNhuCau','HoSoTrinhDuyet','DuAn'],false]
 ];
 for(const[name,title,sel,refs,overview]of specs){const own=overview?sel:Object.keys(model.classes).filter(c=>sel.includes(model.packages[c]));const keep=[...new Set([...own,...refs])];const folder=ROOT+'/II.3_Domain_Class_Diagram';const rels=model.relations.filter(r=>keep.includes(r.a)&&keep.includes(r.b)&&(own.includes(r.a)||own.includes(r.b)));
  // Bố cục ô cố định: giữ cỡ chữ khi in A4, đường đi trong các rãnh giữa lớp.
  const cols=keep.length>9?4:3, rows=Math.ceil(keep.length/cols);
  const scene=new Scene(name,cols*370+60,rows*215+95,title);
  const coords={};
  keep.forEach((c,i)=>{let x=30+(i%cols)*370,y=65+Math.floor(i/cols)*215;
   const attrs=overview||!own.includes(c)?[]:model.classes[c].slice(0,2);
   const lines=cname(c).split('<BR/>');const label=lines.join('\n')+(attrs.length?'\n'+attrs.join('\n'):'');
   scene.node(c,'',x,y,310,135,'box',own.includes(c)?'white':'#f2f2f2',18);
   scene.nodes[scene.nodes.length-1].label=label;
   scene.text(lines.join('\n'),x+155,y+27,18,true);
   if(attrs.length){let yy=y+(lines.length>1?61:44);scene.svg.push(`<line x1="${x}" y1="${yy}" x2="${x+310}" y2="${yy}" stroke="#333"/>`);scene.text(attrs.join('\n'),x+155,yy+24,16);}
   coords[c]={x,y};
  });
  const usedOut={},usedIn={};
  rels.forEach((r,i)=>{let a=coords[r.a],b=coords[r.b];let ia=usedOut[r.a]||0,ib=usedIn[r.b]||0;usedOut[r.a]=ia+1;usedIn[r.b]=ib+1;
   let sx=a.x+30+(ia%5)*55, sy=a.y+135, tx=b.x+30+(ib%5)*55,ty=b.y;
   let rail=a.x+325+(i%4)*8;let mid=sy+28+(i%3)*12;let before=ty-16-(i%3)*8;
   let pts=[[sx,sy],[sx,mid],[rail,mid],[rail,before],[tx,before],[tx,ty]];
   scene.edge(r.a,r.b,pts,'',false);
   if(!overview){if(r.ma)scene.text(r.ma,sx+3,sy+17,13,false,'start');if(r.mb)scene.text(r.mb,tx+3,ty-4,13,false,'start');}
   if(r.kind==='*--'||r.kind==='o--')scene.svg.push(`<polygon points="${sx},${sy} ${sx-5},${sy+7} ${sx},${sy+14} ${sx+5},${sy+7}" fill="${r.kind==='*--'?'#333':'white'}" stroke="#333"/>`);
  });
  await scene.save(folder);
  // Bổ sung nhãn quan hệ và ký hiệu kết tập trên nguồn chỉnh sửa.
  let xml=fs.readFileSync(folder+'/'+name+'.drawio','utf8');
  rels.forEach((r,i)=>{let old=`id="e${i}" value=""`;let val=[r.ma,r.label,r.mb].filter(Boolean).join(' / ');xml=xml.replace(old,`id="e${i}" value="${esc(val)}"`);
   if(r.kind==='*--'||r.kind==='o--')xml=xml.replace(new RegExp(`(id="e${i}"[^>]*style=")`),`$1startArrow=diamond;startFill=${r.kind==='*--'?'1':'0'};`);
  });fs.writeFileSync(folder+'/'+name+'.drawio',xml);
  console.log(name,own.length,'classes',keep.length,'shown');
 }
}
(async()=>{await tree();await v10();await classes();})().catch(e=>{console.error(e);process.exit(1);});
