# Bộ Phần II sơ bộ — PTTKHTTT

Mở `BAO_CAO/PTTKHTTT_PHAN_II_SO_BO.docx` để đọc bản tổng hợp. Mở `CHOT_NOI_DUNG_CHUNG.md` để duyệt các điểm chung và 9 điểm còn mở. Đây là bản sơ bộ trình nhóm xem xét, không phải xác nhận mọi đề xuất đã được duyệt.

## File bàn giao

| Sản phẩm | Vị trí |
|---|---|
| Phần II theo Outline, 53 trang | `BAO_CAO/PTTKHTTT_PHAN_II_SO_BO.docx` và PDF cùng tên |
| V10 riêng: hai UC Description, hai AD, quy tắc và kịch bản đối chiếu | `BAO_CAO/V10_UC_DESCRIPTION_VA_AD.docx`; nội dung văn bản ở `II.2_V10/V10_Phan_II.md` |
| II.1: UCD tổng quát | `II.1_Use_Case_Tong_Quat/II1_UC_Tong_Quat.drawio` và PNG/SVG |
| Phân cấp 9 vùng / 28 UC | `I_Phan_ra_chuc_nang/Phan_ra_chuc_nang.drawio` và PNG/SVG |
| FDS Summary chung, đủ 28 mã | `II.1_Use_Case_Tong_Quat/Danh_muc_FDS_Summary.md` |
| UCD từng vùng | `II.2_UCD_cap_vung/UCD_UC-01…08.drawio`; V10 tại `II.2_V10/UCD_UC-09.drawio` |
| II.3: tổng quan và bảy hình chi tiết | `II.3_Domain_Class_Diagram/` — drawio, PNG/SVG, mô hình PlantUML và danh mục lớp/quan hệ |
| Yêu cầu sửa riêng V2–V10, mỗi bảng đúng bốn cột | `BANG_SUA/V2_Yeu_cau_sua.md` … `V10_Yeu_cau_sua.md` |
| Điểm chuẩn hóa / điểm chờ duyệt và căn cứ | `CHOT_NOI_DUNG_CHUNG.md` |

## Cách dùng ngay

1. Gửi đúng bảng `BANG_SUA/Vx_Yeu_cau_sua.md` cho thành viên phụ trách. Dòng theo nguồn có thể sửa ngay; dòng “Cần duyệt” phải chờ quyết định tương ứng.
2. Giữ nguyên mã UC và vị trí chờ trong Word. Thành viên thay phần chờ bằng D/AD đã sửa; không cần viết lại các UC phụ như UC trọng tâm.
3. V4 giữ D/AD hiện có, còn bổ sung bàn giao khi cạn nguồn ứng viên. Những D/AD chưa đạt của các vùng khác không được chèn như đã hoàn thành. V10 có bản mới đầy đủ.
4. Duyệt trước Q-05, Q-07, Q-08, Q-09 để ổn định dữ liệu và quy tắc xử lý cho bước thiết kế. Q-03 chỉ cần quyết định nếu đổi UC cá nhân V3/V8.

Tên mục chính giữ theo Outline: II.1 Phạm vi hệ thống công nghệ; II.2 Mô hình hóa chức năng của hệ thống công nghệ; II.3 Mô hình hóa cấu trúc tĩnh của hệ thống công nghệ; II.4 Mô hình hóa hành vi của hệ thống công nghệ. II.4 có đủ trạng thái, giao tiếp và tuần tự; chưa có sơ đồ giả định.

## Nguồn và giới hạn

- Baseline: I FINAL và Outline. HD-PCCN dùng để giữ danh mục mã/tên; HD-MAU hướng dẫn cách trình bày bài cá nhân. Audit và decision log cũ là đầu vào kiểm tra, không thay quyết định của nhóm.
- Đối chiếu artifact PR #1 tại `cd09aa5d4655743ae4d4f0d158273dc3a77089d0` và nguồn bổ sung trên main `3a5ef26bd0d44f8b33138b74bab215885ded3f54`. I FINAL, Outline và bài thành viên không đổi giữa baseline đã đọc và main bổ sung.
- Đã đọc AD V9 bản drawio và dữ liệu native nhúng trong PNG V8. Bản native V8 ba trang và AD V9 gốc giữ ở `_nguon_thanh_vien/`, **chưa sửa**, để thành viên cập nhật theo bảng sửa. Báo cáo dùng UCD vùng đã chuẩn hóa.
- AD V4 giữ từ DOCX, hiện chỉ có hình; chưa tìm thấy nguồn drawio riêng trong phạm vi truy cập. Không gọi hình này là nguồn chỉnh sửa.
- II.3 hiển thị một số thuộc tính trên hình để dễ đọc; đủ 48 lớp và toàn bộ thuộc tính trong danh mục. Bội số chưa có căn cứ được để trống; mô hình không được coi là đã chốt tuyệt đối trước khi duyệt Q-05. Báo cáo không chứa bảng lớp ứng viên hoặc đề xuất kỹ thuật nội bộ.
- V10 giữ quyền quyết định chuyển thông tin của RM. Điều kiện “khác kỳ trước” **có trong I FINAL I.3.9 bước 7**; đã đính chính nhận định audit cũ, Q-09 cần chốt cách áp dụng với I.1.3.10/CN-121.
- Không sửa I FINAL; không commit, push hay merge repository. Gói này là bản sao đầu ra để xem xét và tích hợp sau.

## Chỉnh sửa và tái tạo

Mở `.drawio` bằng diagrams.net để sửa trực tiếp từng phần tử. PNG/SVG là hình xuất để đưa vào báo cáo. PlantUML chứa đủ thuộc tính và quan hệ II.3; `Danh_muc_lop_va_quan_he.md` là bảng tra cứu cùng mô hình.

`_cong_cu/catalogue.json`, `domain_model.json`, `v10.json` lưu nội dung chung dùng để dựng bản này. `_cong_cu/tao_bao_cao.py` tái tạo hai Word từ dữ liệu và hình trong gói (Python + python-docx + Pillow). `_cong_cu/tao_so_do.cjs` tái tạo cây chức năng, AD V10 và các hình lớp (Node.js + sharp). Công cụ không thay tài liệu gốc trong repository. Nếu đã sửa sơ đồ thủ công, xuất hình từ chính nguồn đã sửa trước khi tái tạo Word; không chạy lại công cụ sinh sơ đồ để ghi đè những sửa tay chưa đồng bộ vào dữ liệu.

Đã kiểm tra: đủ 28 UC / 129 CN được truy vết; 12 vị trí UC trọng tâm; 9 UCD vùng; 48 lớp; 9 bảng sửa bốn cột; đủ ba tiểu mục II.4. Hai Word đã được xuất PDF và kiểm tra hình/trang. Các kịch bản V10 trong bản riêng là đối chiếu D–AD, không phải kiểm thử phần mềm.
